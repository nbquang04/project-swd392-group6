
export const endpoint = {
  AUTH: '/auth',
  PRODUCT: '/products',
  CATEGORY: '/categories',
  USER: '/users',
  CART: '/carts',
  ORDERS: '/orders',
  REVIEWS: '/reviews'
}
