
import instance from ".";
import { endpoint } from "./endpoints";

// ===== ORDER FUNCTIONS =====

// Lấy danh sách đơn hàng của người dùng
export const fetchOrders = async (filters = {}) => {
  try {
    const qp = new URLSearchParams(filters).toString();
    const { data } = await instance.get(`${endpoint.ORDERS}/me${qp ? `?${qp}` : ''}`);
    return data;
  } catch (error) {
    console.error('Fetch orders error:', error);
    return [];
  }
};

// Lấy chi tiết đơn hàng theo ID
export const getOrderById = async (orderId) => {
  try {
    const { data } = await instance.get(`${endpoint.ORDERS}/${orderId}`);
    return data;
  } catch (error) {
    console.error('Get order by ID error:', error);
    return null;
  }
};

// Tạo đơn hàng mới
export const placeOrder = async (payload) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/me`, payload);
    return data;
  } catch (error) {
    console.error('Place order error:', error);
    throw error;
  }
};

// Cập nhật trạng thái đơn hàng (Admin)
export const updateOrderStatus = async (orderId, status) => {
  try {
    const { data } = await instance.put(`${endpoint.ORDERS}/${orderId}`, { status });
    return data;
  } catch (error) {
    console.error('Update order status error:', error);
    throw error;
  }
};

// Hủy đơn hàng
export const cancelOrder = async (orderId, reason = '') => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/cancel`, { reason });
    return data;
  } catch (error) {
    console.error('Cancel order error:', error);
    throw error;
  }
};

// Xác nhận đơn hàng
export const confirmOrder = async (orderId) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/confirm`);
    return data;
  } catch (error) {
    console.error('Confirm order error:', error);
    throw error;
  }
};

// Đánh dấu đơn hàng đã giao
export const markAsDelivered = async (orderId) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/delivered`);
    return data;
  } catch (error) {
    console.error('Mark as delivered error:', error);
    throw error;
  }
};

// Lấy lịch sử trạng thái đơn hàng
export const getOrderStatusHistory = async (orderId) => {
  try {
    const { data } = await instance.get(`${endpoint.ORDERS}/${orderId}/status-history`);
    return data;
  } catch (error) {
    console.error('Get order status history error:', error);
    return [];
  }
};

// Tạo yêu cầu hoàn trả
export const requestRefund = async (orderId, reason, amount = null) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/refund`, {
      reason,
      amount
    });
    return data;
  } catch (error) {
    console.error('Request refund error:', error);
    throw error;
  }
};

// Lấy danh sách yêu cầu hoàn trả
export const getRefundRequests = async (orderId) => {
  try {
    const { data } = await instance.get(`${endpoint.ORDERS}/${orderId}/refunds`);
    return data;
  } catch (error) {
    console.error('Get refund requests error:', error);
    return [];
  }
};

// Tạo đánh giá đơn hàng
export const reviewOrder = async (orderId, reviewData) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/review`, reviewData);
    return data;
  } catch (error) {
    console.error('Review order error:', error);
    throw error;
  }
};

// Lấy đánh giá đơn hàng
export const getOrderReview = async (orderId) => {
  try {
    const { data } = await instance.get(`${endpoint.ORDERS}/${orderId}/review`);
    return data;
  } catch (error) {
    console.error('Get order review error:', error);
    return null;
  }
};

// Tái đặt hàng
export const reorder = async (orderId) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/reorder`);
    return data;
  } catch (error) {
    console.error('Reorder error:', error);
    throw error;
  }
};

// Lấy thống kê đơn hàng
export const getOrderStats = async (filters = {}) => {
  try {
    const qp = new URLSearchParams(filters).toString();
    const { data } = await instance.get(`${endpoint.ORDERS}/stats${qp ? `?${qp}` : ''}`);
    return data;
  } catch (error) {
    console.error('Get order stats error:', error);
    return null;
  }
};

// Xuất hóa đơn
export const exportInvoice = async (orderId) => {
  try {
    const response = await instance.get(`${endpoint.ORDERS}/${orderId}/invoice`, {
      responseType: 'blob'
    });
    return response.data;
  } catch (error) {
    console.error('Export invoice error:', error);
    throw error;
  }
};

// Gửi email xác nhận đơn hàng
export const sendOrderConfirmation = async (orderId) => {
  try {
    const { data } = await instance.post(`${endpoint.ORDERS}/${orderId}/send-confirmation`);
    return data;
  } catch (error) {
    console.error('Send order confirmation error:', error);
    throw error;
  }
};

// Lấy mã theo dõi đơn hàng
export const getTrackingInfo = async (orderId) => {
  try {
    const { data } = await instance.get(`${endpoint.ORDERS}/${orderId}/tracking`);
    return data;
  } catch (error) {
    console.error('Get tracking info error:', error);
    return null;
  }
};

// Cập nhật thông tin giao hàng
export const updateShippingInfo = async (orderId, shippingInfo) => {
  try {
    const { data } = await instance.put(`${endpoint.ORDERS}/${orderId}/shipping`, shippingInfo);
    return data;
  } catch (error) {
    console.error('Update shipping info error:', error);
    throw error;
  }
};

// Lấy tất cả đơn hàng (Admin)
export const getAllOrders = async (filters = {}) => {
  try {
    const qp = new URLSearchParams(filters).toString();
    const { data } = await instance.get(`${endpoint.ORDERS}${qp ? `?${qp}` : ''}`);
    return data;
  } catch (error) {
    console.error('Get all orders error:', error);
    return [];
  }
};

// Cập nhật ghi chú đơn hàng (Admin)
export const updateOrderNotes = async (orderId, notes) => {
  try {
    const { data } = await instance.put(`${endpoint.ORDERS}/${orderId}/notes`, { notes });
    return data;
  } catch (error) {
    console.error('Update order notes error:', error);
    throw error;
  }
};
