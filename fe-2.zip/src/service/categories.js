import instance from './index.js';
import { endpoint } from './endpoints.js';

// ===== CATEGORY FUNCTIONS =====

// Lấy danh sách tất cả danh mục
export const fetchCategories = async () => {
  try {
    const response = await instance.get(endpoint.CATEGORY);
    return response.data;
  } catch (error) {
    console.error('Fetch categories error:', error);
    return [];
  }
};

// Lấy chi tiết danh mục theo ID
export const getCategoryById = async (categoryId) => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/${categoryId}`);
    return response.data;
  } catch (error) {
    console.error('Get category by ID error:', error);
    return null;
  }
};

// Tạo danh mục mới (Admin)
export const createCategory = async (categoryData) => {
  try {
    const response = await instance.post(endpoint.CATEGORY, categoryData);
    return response.data;
  } catch (error) {
    console.error('Create category error:', error);
    throw error;
  }
};

// Cập nhật danh mục (Admin)
export const updateCategory = async (categoryId, categoryData) => {
  try {
    const response = await instance.put(`${endpoint.CATEGORY}/${categoryId}`, categoryData);
    return response.data;
  } catch (error) {
    console.error('Update category error:', error);
    throw error;
  }
};

// Xóa danh mục (Admin)
export const deleteCategory = async (categoryId) => {
  try {
    const response = await instance.delete(`${endpoint.CATEGORY}/${categoryId}`);
    return response.data;
  } catch (error) {
    console.error('Delete category error:', error);
    throw error;
  }
};

// Lấy danh mục con
export const getSubCategories = async (parentId) => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/${parentId}/subcategories`);
    return response.data;
  } catch (error) {
    console.error('Get subcategories error:', error);
    return [];
  }
};

// Tạo danh mục con
export const createSubCategory = async (parentId, subCategoryData) => {
  try {
    const response = await instance.post(`${endpoint.CATEGORY}/${parentId}/subcategories`, subCategoryData);
    return response.data;
  } catch (error) {
    console.error('Create subcategory error:', error);
    throw error;
  }
};

// Cập nhật trạng thái danh mục (Admin)
export const updateCategoryStatus = async (categoryId, status) => {
  try {
    const response = await instance.patch(`${endpoint.CATEGORY}/${categoryId}/status`, { status });
    return response.data;
  } catch (error) {
    console.error('Update category status error:', error);
    throw error;
  }
};

// Sắp xếp lại thứ tự danh mục (Admin)
export const reorderCategories = async (categoryOrders) => {
  try {
    const response = await instance.post(`${endpoint.CATEGORY}/reorder`, { categoryOrders });
    return response.data;
  } catch (error) {
    console.error('Reorder categories error:', error);
    throw error;
  }
};

// Lấy danh mục phổ biến
export const getPopularCategories = async (limit = 10) => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/popular?limit=${limit}`);
    return response.data;
  } catch (error) {
    console.error('Get popular categories error:', error);
    return [];
  }
};

// Tìm kiếm danh mục
export const searchCategories = async (query) => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/search?q=${encodeURIComponent(query)}`);
    return response.data;
  } catch (error) {
    console.error('Search categories error:', error);
    return [];
  }
};

// Lấy thống kê danh mục (Admin)
export const getCategoryStats = async (categoryId) => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/${categoryId}/stats`);
    return response.data;
  } catch (error) {
    console.error('Get category stats error:', error);
    return null;
  }
};

// Lấy cây danh mục (hierarchical)
export const getCategoryTree = async () => {
  try {
    const response = await instance.get(`${endpoint.CATEGORY}/tree`);
    return response.data;
  } catch (error) {
    console.error('Get category tree error:', error);
    return [];
  }
};

// Cập nhật hình ảnh danh mục
export const updateCategoryImage = async (categoryId, imageFile) => {
  try {
    const formData = new FormData();
    formData.append('image', imageFile);
    const response = await instance.post(`${endpoint.CATEGORY}/${categoryId}/image`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return response.data;
  } catch (error) {
    console.error('Update category image error:', error);
    throw error;
  }
};

// Xóa hình ảnh danh mục
export const deleteCategoryImage = async (categoryId) => {
  try {
    const response = await instance.delete(`${endpoint.CATEGORY}/${categoryId}/image`);
    return response.data;
  } catch (error) {
    console.error('Delete category image error:', error);
    throw error;
  }
};
