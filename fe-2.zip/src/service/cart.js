
import instance from ".";
import { endpoint } from "./endpoints";

// ===== CART FUNCTIONS =====

// Lấy giỏ hàng của người dùng hiện tại
export const getMyCart = async () => {
  try {
    const { data } = await instance.get(`${endpoint.CART}/me`);
    return data;
  } catch (error) {
    console.error('Get cart error:', error);
    return { items: [], total: 0 };
  }
};

// Legacy-compatible for Header1 & ShopCartDetail (expects array of carts)
export const fetchCart = async () => {
  try {
    const { data } = await instance.get(`${endpoint.CART}/me`);
    const userStr = localStorage.getItem('user');
    let userId = null; 
    try { 
      userId = JSON.parse(userStr)?.id 
    } catch {}
    const cart = data && typeof data === 'object' ? { ...data } : { items: [] };
    if (userId && !cart.user_id) cart.user_id = String(userId);
    return [cart];
  } catch (error) {
    console.error('Fetch cart error:', error);
    return [];
  }
};

// Thêm sản phẩm vào giỏ hàng
export const addToCart = async ({ productId, variantId = null, quantity = 1, price = 0 }) => {
  try {
    const params = new URLSearchParams({ productId, quantity, price });
    if (variantId) params.append('variantId', variantId);
    const { data } = await instance.post(`${endpoint.CART}/me/items?${params.toString()}`);
    return data;
  } catch (error) {
    console.error('Add to cart error:', error);
    throw error;
  }
};

// Cập nhật số lượng sản phẩm trong giỏ hàng
export const updateCartItem = async (itemId, quantity) => {
  try {
    const { data } = await instance.put(`${endpoint.CART}/me/items/${itemId}`, { quantity });
    return data;
  } catch (error) {
    console.error('Update cart item error:', error);
    throw error;
  }
};

// Xóa sản phẩm khỏi giỏ hàng
export const removeFromCart = async (itemId) => {
  try {
    const { data } = await instance.delete(`${endpoint.CART}/me/items/${itemId}`);
    return data;
  } catch (error) {
    console.error('Remove from cart error:', error);
    throw error;
  }
};

// Xóa tất cả sản phẩm khỏi giỏ hàng
export const clearCart = async () => {
  try {
    const { data } = await instance.delete(`${endpoint.CART}/me`);
    return data;
  } catch (error) {
    console.error('Clear cart error:', error);
    throw error;
  }
};

// Lấy tổng số lượng sản phẩm trong giỏ hàng
export const getCartItemCount = async () => {
  try {
    const cart = await getMyCart();
    return cart.items ? cart.items.reduce((total, item) => total + item.quantity, 0) : 0;
  } catch (error) {
    console.error('Get cart item count error:', error);
    return 0;
  }
};

// Lấy tổng giá trị giỏ hàng
export const getCartTotal = async () => {
  try {
    const cart = await getMyCart();
    return cart.total || 0;
  } catch (error) {
    console.error('Get cart total error:', error);
    return 0;
  }
};

// Kiểm tra sản phẩm có trong giỏ hàng không
export const isProductInCart = async (productId, variantId = null) => {
  try {
    const cart = await getMyCart();
    if (!cart.items) return false;
    
    return cart.items.some(item => {
      if (variantId) {
        return item.productId === productId && item.variantId === variantId;
      }
      return item.productId === productId;
    });
  } catch (error) {
    console.error('Check product in cart error:', error);
    return false;
  }
};

// Lấy số lượng sản phẩm cụ thể trong giỏ hàng
export const getProductQuantityInCart = async (productId, variantId = null) => {
  try {
    const cart = await getMyCart();
    if (!cart.items) return 0;
    
    const item = cart.items.find(item => {
      if (variantId) {
        return item.productId === productId && item.variantId === variantId;
      }
      return item.productId === productId;
    });
    
    return item ? item.quantity : 0;
  } catch (error) {
    console.error('Get product quantity in cart error:', error);
    return 0;
  }
};

// Áp dụng mã giảm giá
export const applyCoupon = async (couponCode) => {
  try {
    const { data } = await instance.post(`${endpoint.CART}/me/coupon`, { couponCode });
    return data;
  } catch (error) {
    console.error('Apply coupon error:', error);
    throw error;
  }
};

// Xóa mã giảm giá
export const removeCoupon = async () => {
  try {
    const { data } = await instance.delete(`${endpoint.CART}/me/coupon`);
    return data;
  } catch (error) {
    console.error('Remove coupon error:', error);
    throw error;
  }
};

// Lưu giỏ hàng cho sau (Wishlist)
export const saveForLater = async (itemId) => {
  try {
    const { data } = await instance.post(`${endpoint.CART}/me/save-for-later`, { itemId });
    return data;
  } catch (error) {
    console.error('Save for later error:', error);
    throw error;
  }
};

// Lấy danh sách sản phẩm đã lưu
export const getSavedItems = async () => {
  try {
    const { data } = await instance.get(`${endpoint.CART}/me/saved`);
    return data;
  } catch (error) {
    console.error('Get saved items error:', error);
    return [];
  }
};

// Chuyển sản phẩm từ saved về cart
export const moveToCart = async (itemId) => {
  try {
    const { data } = await instance.post(`${endpoint.CART}/me/move-to-cart`, { itemId });
    return data;
  } catch (error) {
    console.error('Move to cart error:', error);
    throw error;
  }
};

// Xóa sản phẩm khỏi danh sách đã lưu
export const removeFromSaved = async (itemId) => {
  try {
    const { data } = await instance.delete(`${endpoint.CART}/me/saved/${itemId}`);
    return data;
  } catch (error) {
    console.error('Remove from saved error:', error);
    throw error;
  }
};

// Tính phí vận chuyển
export const calculateShipping = async (address) => {
  try {
    const { data } = await instance.post(`${endpoint.CART}/me/shipping`, address);
    return data;
  } catch (error) {
    console.error('Calculate shipping error:', error);
    throw error;
  }
};

// Lấy thông tin thanh toán
export const getCheckoutInfo = async () => {
  try {
    const { data } = await instance.get(`${endpoint.CART}/me/checkout`);
    return data;
  } catch (error) {
    console.error('Get checkout info error:', error);
    throw error;
  }
};
