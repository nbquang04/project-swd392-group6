export const endpoint = {
    PRODUCT: 'products',
    CATEGORY: 'category',
    USER: 'users',
    CART: 'cart',
    ORDERS: 'orders',
    REVIEWS: 'reviews'
}