export { default as BasicInfoTab } from './BasicInfoTab';
export { default as VariantsTab } from './VariantsTab';
